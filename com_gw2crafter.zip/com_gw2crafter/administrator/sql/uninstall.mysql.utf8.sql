DROP TABLE IF EXISTS `#__gw2crafter_api_item`;
